import unittest
from unittest.mock import patch
from io import StringIO
from library_management.toolbox.library import Library
from library_management.toolbox.user import User
from library_management.toolbox.book import Book
from library_management.analysis.lending import lend, return_book

class TestLibraryLending(unittest.TestCase):
    
    def setUp(self):
        # 创建一个测试库实例
        self.library = Library('D:/LibraryProject/files/library_books_dataset.csv')
        # 假设 User 只接受 4 个位置参数：username, password, borrow_history, 和 return_history
        self.library.logged_in_user = User('test_user', 'password', [], [])
        self.library.books = {
            1: Book(1, 'Test Book 1', 'Author 1', 'Genre 1', '2020', True, 0),
            2: Book(2, 'Test Book 2', 'Author 2', 'Genre 2', '2021', True, 0),
        }

    @patch('builtins.input', side_effect=['1'])  # 模拟用户输入书籍 ID 为 1
    @patch('sys.stdout', new_callable=StringIO)  # 捕获打印输出
    def test_lend_book(self, mock_stdout, mock_input):
        lend(self.library)  # 借书操作
        book = self.library.books[1]
        
        # 断言书籍已被借出
        self.assertFalse(book.availability)
        self.assertEqual(book.borrow_count, 1)
        self.assertIn('Test Book 1', self.library.logged_in_user.borrow_history)
        
        # 检查打印输出
        printed_output = mock_stdout.getvalue()
        self.assertIn("Book 'Test Book 1' has been successfully lent.", printed_output)

    @patch('builtins.input', side_effect=['1'])  # 模拟用户输入书籍 ID 为 1
    @patch('sys.stdout', new_callable=StringIO)  # 捕获打印输出
    def test_return_book(self, mock_stdout, mock_input):
        # 先借出书籍以设置为不可用
        self.library.books[1].availability = False
        self.library.logged_in_user.borrow_history.append('Test Book 1')
        
        return_book(self.library)  # 还书操作
        book = self.library.books[1]
        
        # 断言书籍已被归还
        self.assertTrue(book.availability)
        
        # 检查打印输出
        printed_output = mock_stdout.getvalue()
        self.assertIn("Book 'Test Book 1' has been successfully returned.", printed_output)

if __name__ == '__main__':
    unittest.main()
