# test_library.py
import unittest
import os
import builtins 
import csv
from library_management.toolbox.btree import BTree  # Ensure the correct path
from library_management.toolbox.book import Book  # Ensure the correct path
from library_management.toolbox.user import User  # Ensure the correct path
from library_management.toolbox.library import Library

class TestLibrary(unittest.TestCase):

    def setUp(self):
        # 创建一个临时 CSV 文件用于测试
        self.filename = 'test_books.csv'
        self.user_filename = 'test_users.csv'
        
        with open(self.filename, 'w', newline='', encoding='utf-8') as outFile:
            writer = csv.writer(outFile)
            writer.writerow(["ID", "Title", "Author", "Genre", "Publication Year", "Availability", "Borrow Count"])
            writer.writerow([1, 'Book1', 'Author1', 'Genre1', '2000', 'True', 10])
            writer.writerow([2, 'Book2', 'Author2', 'Genre2', '2010', 'False', 5])
        
        with open(self.user_filename, 'w', newline='', encoding='utf-8') as outFile:
            writer = csv.writer(outFile)
            writer.writerow(["Nickname", "Username", "Password", "Borrow History", "Most Borrowed Genre", "Most Borrowed Author"])
            writer.writerow(['Nick1', 'user1', 'pass1', '', '', ''])

        self.library = Library(self.filename)
        self.library.read_user_file(self.user_filename)

    def tearDown(self):
        # 在测试后移除临时 CSV 文件
        os.remove(self.filename)
        os.remove(self.user_filename)

    def test_read_file(self):
        self.assertEqual(self.library.total, 2)
        book1 = self.library.search(1)
        book2 = self.library.search(2)
        self.assertIsNotNone(book1)
        self.assertIsNotNone(book2)
        self.assertEqual(book1.title, 'Book1')
        self.assertEqual(book2.title, 'Book2')

    def test_add_book(self):
        self.library.logged_in_user = User("nick", "testuser", "testpass")  # 模拟已登录用户
        book = Book(3, 'Book3', 'Author3', 'Genre3', '2020', True, 0)
        self.library.books.insert(book)
        self.library.total += 1
        self.library.write_file(self.filename)  # 添加后保存文件
        self.library.read_file(self.filename)  # 重新加载图书数据

        added_book = self.library.search(3)
        self.assertIsNotNone(added_book)
        self.assertEqual(added_book.title, 'Book3')
        self.assertEqual(self.library.total, 3)

    def test_login(self):
        # 模拟用户输入
        original_input = builtins.input
        builtins.input = lambda _: 'user1' if 'username' in _ else 'pass1'

        try:
            self.assertTrue(self.library.login())
            self.assertEqual(self.library.logged_in_user.username, 'user1')
        finally:
            # 恢复原始的 input 函数
            builtins.input = original_input

    def test_remove_book(self):
        self.library.logged_in_user = User("nick", "testuser", "testpass")  # 模拟已登录用户
        
        # 模拟用户输入
        original_input = builtins.input
        builtins.input = lambda _: '1' if 'Enter book ID to remove' in _ else 'y'

        try:
            self.library.remove()
            removed_book = self.library.search(1)
            self.assertIsNone(removed_book)
            self.assertEqual(self.library.total, 1)
        finally:
            # 恢复原始的 input 函数
            builtins.input = original_input

    def test_search_by_attribute(self):
        print("Testing search_by_attribute method...")
        results = self.library.search_by_attribute('author', 'Author1')
        print(f"Results: {results}")
        
        if results is not None:
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0].title, 'Book1')
        else:
            self.fail("search_by_attribute returned None unexpectedly")

if __name__ == '__main__':
    unittest.main()