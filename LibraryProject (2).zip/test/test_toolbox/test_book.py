import unittest
from io import StringIO
from unittest.mock import patch
from library_management.toolbox.book import Book  # Assuming your Book class is in a file named 'book.py'

class TestBook(unittest.TestCase):

    def test_book_initialization(self):
        book = Book(1, "Book Title", "Author Name", "Fiction", "2022", True, 10)
        self.assertEqual(book.book_id, 1)
        self.assertEqual(book.title, "Book Title")
        self.assertEqual(book.author, "Author Name")
        self.assertEqual(book.genre, "Fiction")
        self.assertEqual(book.publication, "2022")
        self.assertTrue(book.availability)
        self.assertEqual(book.borrow_count, 10)

    def test_print_method(self):
        book = Book(1, "Book Title", "Author Name", "Fiction", "2022", True, 10)
        expected_output = (
            "-------------------------------\n"
            "Book information:\n"
            "ID: 1\n"
            "Title: Book Title\n"
            "Author: Author Name\n"
            "Genre: Fiction\n"
            "Publication Year: 2022\n"
            "Availability: Available\n"
            "Borrow Count: 10\n"
            "-------------------------------\n"
        )
        with patch('sys.stdout', new=StringIO()) as fake_out:
            book.print()
            self.assertEqual(fake_out.getvalue(), expected_output)

    def test_comparison_operators(self):
        book1 = Book(1, "Book Title", "Author Name", "Fiction", "2022", True, 10)
        book2 = Book(2, "Another Book", "Different Author", "Non-fiction", "2023", False, 5)

        self.assertTrue(book1 < book2)
        self.assertFalse(book1 > book2)
        self.assertFalse(book1 == book2)
        self.assertTrue(book1 == Book(1, "Book Title", "Author Name", "Fiction", "2022", True, 10))

if __name__ == "__main__":
    unittest.main()
