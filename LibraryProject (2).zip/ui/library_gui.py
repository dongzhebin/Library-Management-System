import sys
import csv
import traceback
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QInputDialog
from library_management.toolbox.user import User
from library_management.toolbox.library import Library
from library_management.analysis.lending import lend
from library_management.analysis.lending import update_borrow_stats
from library_management.analysis.lending import return_book
from library_management.analysis.recommandation import recommend
from library_management.toolbox.book import Book
class LibraryGUI(QMainWindow):
    def __init__(self, library):
        super().__init__()
        self.library = library
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Library Management System')

        layout = QVBoxLayout()

        self.registerButton = QPushButton('Register', self)
        self.registerButton.clicked.connect(self.register)
        layout.addWidget(self.registerButton)

        self.loginButton = QPushButton('Login', self)
        self.loginButton.clicked.connect(self.login)
        layout.addWidget(self.loginButton)

        self.searchButton = QPushButton('Search Book', self)
        self.searchButton.clicked.connect(self.search_book)
        layout.addWidget(self.searchButton)

        self.addButton = QPushButton('Add Book', self)
        self.addButton.clicked.connect(self.add_book)
        layout.addWidget(self.addButton)

        self.deleteButton = QPushButton('Delete Book', self)
        self.deleteButton.clicked.connect(self.delete_book)
        layout.addWidget(self.deleteButton)

        self.modifyButton = QPushButton('Modify Book', self)
        self.modifyButton.clicked.connect(self.modify_book)
        layout.addWidget(self.modifyButton)

        self.displayButton = QPushButton('Display Inventory', self)
        self.displayButton.clicked.connect(self.display_inventory)
        layout.addWidget(self.displayButton)

        self.recommendButton = QPushButton('Recommend Books', self)
        self.recommendButton.clicked.connect(self.recommend_books)
        layout.addWidget(self.recommendButton)

        self.borrowButton = QPushButton('Borrow Book', self)
        self.borrowButton.clicked.connect(self.borrow_book)
        layout.addWidget(self.borrowButton)

        self.returnButton = QPushButton('Return Book', self)
        self.returnButton.clicked.connect(self.return_book)
        layout.addWidget(self.returnButton)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def add_book(self):
        try:
            book_id, ok1 = QInputDialog.getInt(self, 'Add Book', 'Enter book ID:')
            if not ok1:
                return
            title, ok2 = QInputDialog.getText(self, 'Add Book', 'Enter book title:')
            if not ok2:
                return
            author, ok3 = QInputDialog.getText(self, 'Add Book', 'Enter author:')
            if not ok3:
                return
            genre, ok4 = QInputDialog.getText(self, 'Add Book', 'Enter genre:')
            if not ok4:
                return
            publication, ok5 = QInputDialog.getText(self, 'Add Book', 'Enter publication year:')
            if not ok5:
                return
            availability, ok6 = QInputDialog.getItem(self, 'Add Book', 'Enter availability:', ['True', 'False'], 0, False)
            if not ok6:
                return
            borrow_count, ok7 = QInputDialog.getInt(self, 'Add Book', 'Enter borrow count:')
            if not ok7:
                return

            aBook = Book(book_id, title, author, genre, publication, availability == 'True', borrow_count)
            if self.library.is_unique(book_id, title):
                self.library.books.insert(aBook)
                self.library.total += 1
                self.library.write_file(self.library.filename)
                QMessageBox.information(self, 'Success', 'Book added successfully.')
            else:
                QMessageBox.warning(self, 'Error', 'Book ID or Title already exists.')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()
    
    def delete_book(self):
        try:
            book_id, ok = QInputDialog.getInt(self, 'Delete Book', 'Enter book ID to delete:')
            if not ok:
                return
            if self.library.remove_book(book_id):
                QMessageBox.information(self, 'Success', 'Book deleted successfully.')
            else:
                QMessageBox.warning(self, 'Error', 'Book ID not found.')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def display_inventory(self):
        if self.library.total == 0:
            QMessageBox.information(self, 'Inventory', 'No books in inventory.')
        else:
            books_info = []
            self.library.books.traverse(lambda book: books_info.append(f"ID: {book.book_id}, Title: {book.title}, Author: {book.author}, Genre: {book.genre}, Publication: {book.publication}, Availability: {book.availability}, Borrow Count: {book.borrow_count}"))
            QMessageBox.information(self, 'Inventory', '\n'.join(books_info))

    def search_book(self):
        try:
            search_keyword, ok = QInputDialog.getText(self, 'Search Book', 'Enter keyword to search:')
            if not ok:
                return
            books = self.library.books.search_by_title(search_keyword)
            if books:
                book_info = "\n\n".join([f"ID: {book.book_id}\nTitle: {book.title}\nAuthor: {book.author}\nGenre: {book.genre}\nPublication Year: {book.publication}\nAvailability: {'Available' if book.availability else 'Not Available'}\nBorrow Count: {book.borrow_count}" for book in books])
                QMessageBox.information(self, 'Books Found', book_info)
            else:
                QMessageBox.warning(self, 'Error', 'No books found matching the keyword.')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def borrow_book(self):
        try:
            title, ok = QInputDialog.getText(self, 'Borrow Book', 'Enter book title to borrow:')
            if not ok:
                return
            success, result = self.library.borrow_book(title)
            if success:
                book = result
                QMessageBox.information(self, 'Success', f'You have successfully borrowed "{book.title}".')
            else:
                QMessageBox.warning(self, 'Error', result)
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def return_book(self):
        try:
            title, ok = QInputDialog.getText(self, 'Return Book', 'Enter book title to return:')
            if not ok:
                return
            success, result = self.library.return_book(title)
            if success:
                book = result
                QMessageBox.information(self, 'Success', f'You have successfully returned "{book.title}".')
            else:
                QMessageBox.warning(self, 'Error', result)
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def login(self):
        try:
            username, ok1 = QInputDialog.getText(self, 'Login', 'Enter your username:')
            if not ok1:
                return
            password, ok2 = QInputDialog.getText(self, 'Login', 'Enter your password:')
            if not ok2:
                return

            for user in self.library.users:
                if user.username == username and user.password == password:
                    self.library.logged_in_user = user
                    QMessageBox.information(self, 'Login', f'Welcome, {user.nickname}!')
                    return

            QMessageBox.warning(self, 'Login', 'Invalid username or password.')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def register(self):
        try:
            nickname, ok1 = QInputDialog.getText(self, 'Register', 'Enter your nickname:')
            if not ok1:
                return
            username, ok2 = QInputDialog.getText(self, 'Register', 'Enter your username:')
            if not ok2:
                return
            password, ok3 = QInputDialog.getText(self, 'Register', 'Enter your password:')
            if not ok3:
                return

            user = User(nickname, username, password)
            self.library.users.append(user)
            self.library.write_user_file('users.csv')
            QMessageBox.information(self, 'Register', 'Registration successful!')
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            traceback.print_exc()

    def recommend_books(self):
        try:
            recommended_books = self.library.recommend_books()
            if isinstance(recommended_books, str):
                QMessageBox.warning(self, 'Error', recommended_books)
            else:
                book_info = "\n\n".join([f"ID: {book.book_id}\nTitle: {book.title}\nAuthor: {book.author}\nGenre: {book.genre}\nPublication Year: {book.publication}\nAvailability: {'Available' if book.availability else 'Not Available'}\nBorrow Count: {book.borrow_count}" for book in recommended_books])
                QMessageBox.information(self, 'Recommended Books', book_info)
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, 'Error', f'An error occurred: {e}')
            
    def modify_book(self):
        book_id, ok = QInputDialog.getInt(self, 'Modify Book', 'Enter book ID to modify:')
        if not ok:
            return

        book = self.library.books.search_tree(book_id)
        if book is None:
            QMessageBox.warning(self, 'Error', 'Book not found.')
            return

        new_title, ok1 = QInputDialog.getText(self, 'Modify Book', 'Enter new title:', text=book.title)
        if not ok1:
            return
        new_author, ok2 = QInputDialog.getText(self, 'Modify Book', 'Enter new author:', text=book.author)
        if not ok2:
            return
        new_genre, ok3 = QInputDialog.getText(self, 'Modify Book', 'Enter new genre:', text=book.genre)
        if not ok3:
            return
        new_publication, ok4 = QInputDialog.getText(self, 'Modify Book', 'Enter new publication year:', text=book.publication)
        if not ok4:
            return
        new_availability, ok5 = QInputDialog.getItem(self, 'Modify Book', 'Enter new availability:', ['True', 'False'], 0, False)
        if not ok5:
            return
        new_borrow_count, ok6 = QInputDialog.getInt(self, 'Modify Book', 'Enter new borrow count:', value=book.borrow_count)
        if not ok6:
            return

        # 更新书籍信息
        book.title = new_title
        book.author = new_author
        book.genre = new_genre
        book.publication = new_publication
        book.availability = new_availability == 'True'
        book.borrow_count = new_borrow_count

        # 更新CSV文件
        self.library.write_file(self.library.filename)
        QMessageBox.information(self, 'Success', 'Book modified successfully.')
    def is_unique(self, book_id, title):
        for book in self.books:
            if book.book_id == book_id or book.title == title:
                return False
        return True