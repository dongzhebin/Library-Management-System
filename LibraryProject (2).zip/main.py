import os
import sys
import csv
import unittest
import sys
import traceback
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QInputDialog
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))  
from library_management.toolbox.library import Library
from library_management.analysis.lending import lend
from library_management.analysis.lending import update_borrow_stats
from library_management.analysis.lending import return_book
from library_management.analysis.recommandation import recommend
from library_management.analysis.btree_visualization import BTree, read_book_ids, plot_btree
from ui.library_gui import LibraryGUI

from library_management.utils import read_csv
from library_management.toolbox.library import Library

from library_management.toolbox.user import User

def main():
    # 获取当前文件所在的目录，并将其父目录添加到系统路径中
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.abspath(os.path.join(current_dir, os.pardir))
    sys.path.append(parent_dir)
    
    # 设置文件路径
    filename = r"D:/LibraryProject/files/library_books_dataset.csv"
    
    # 创建 Librar 实例并读取文件
    myLib = Library(filename)
    library = Library('files/library_books_dataset.csv')
    library.read_user_file('users.csv')

    app = QApplication(sys.argv)
    gui = LibraryGUI(library)
    gui.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
