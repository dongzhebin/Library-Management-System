from library_management.toolbox.btree import BTree  # 确保路径正确
from library_management.toolbox.book import Book  # 确保路径正确
from library_management.toolbox.user import User  # 确保路径正确
import csv
from library_management.utils import read_csv
from library_management.analysis.lending import lend, update_borrow_stats, return_book 
# library_management/toolbox/library.py



# 在需要使用的地方调用 read_csv_file 函数

from library_management.utils import read_csv_file  # Example of using a utility function

class User:
    def __init__(self, nickname, username, password):
        self.nickname = nickname
        self.username = username
        self.password = password
        self.borrow_history = []
        self.most_borrowed_genre = ""
        self.most_borrowed_author = ""

class Library:
    def __init__(self, filename):
        self.filename = filename  # Filename
        self.books = BTree(3)    # BTree to save
        self.total = 0
        self.users = []
        
        self.logged_in_user = None
        print("Current inventory information:")
        if filename:
            self.read_file(filename)

    def read_file(self, filename):
        self.total = 0
        with open(filename, 'r', newline='', encoding='utf-8') as inFile:
            reader = csv.reader(inFile)
            next(reader)  # Skip header
            for row in reader:
                book_id = int(row[0])
                title = row[1]
                author = row[2]
                genre = row[3]
                publication = row[4]
                availability = row[5].strip().lower() == 'true'
                borrow_count = int(row[6]) if len(row) > 6 else 0  # Check for borrow_count
                aBook = Book(book_id, title, author, genre, publication, availability, borrow_count)
                aBook.print()
                self.books.insert(aBook)
                self.total += 1
        print(f"There are {self.total} books in inventory")

    def write_file(self, filename):
        with open(filename, 'w', newline='', encoding='utf-8') as outFile:
            writer = csv.writer(outFile)
            writer.writerow(["ID", "Title", "Author", "Genre", "Publication Year", "Availability", "Borrow Count"])
            self.books.traverse(lambda book: writer.writerow([book.book_id, book.title, book.author, book.genre, book.publication, book.availability, book.borrow_count]))
        print("Book information has been updated and saved to the file.")

    def read_user_file(self, filename):
        try:
            with open(filename, 'r', newline='', encoding='utf-8') as inFile:
                reader = csv.reader(inFile)
                next(reader)  # Skip header
                for row in reader:
                    nickname, username, password, borrow_history, most_borrowed_genre, most_borrowed_author = row
                    user = User(nickname, username, password)
                    user.borrow_history = borrow_history.split(';') if borrow_history else []
                    user.most_borrowed_genre = most_borrowed_genre
                    user.most_borrowed_author = most_borrowed_author
                    self.users.append(user)
        except FileNotFoundError:
            print("User file not found. Starting with an empty user list.")

    def write_user_file(self, filename):
        with open(filename, 'w', newline='', encoding='utf-8') as outFile:
            writer = csv.writer(outFile)
            writer.writerow(["Nickname", "Username", "Password", "Borrow History", "Most Borrowed Genre", "Most Borrowed Author"])
            for user in self.users:
                writer.writerow([user.nickname, user.username, user.password, ';'.join(user.borrow_history), user.most_borrowed_genre, user.most_borrowed_author])
        print("User information has been updated and saved to the file.")
    def create_user(self):
        nickname = input("Enter your nickname: ")
        username = input("Enter your username: ")
        if any(user.username == username for user in self.users):
            print("Username already exists. Please choose another username.")
            return
        password = input("Enter your password: ")
        new_user = User(nickname, username, password)
        self.users.append(new_user)
        print("User created successfully.")
        self.write_user_file('users.csv')
    def find_user(self, username):
        for user in self.users:
            if user.username == username:
                return user
        return None
    def register(self, nickname, username, password):
        if self.find_user(username):
            return False, "Username already exists."
        new_user = User(nickname, username, password)
        self.users.append(new_user)
        self.write_user_file('users.csv')
        return True, "Registration successful."

    def login(self):
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        for user in self.users:
            if user.username == username and user.password == password:
                self.logged_in_user = user
                print(f"Welcome, {user.nickname}!")
                return True
        print("Invalid username or password.")
        return False

    def is_unique(self, book_id, title):
        unique = True
        for book in self.books:
            if book.book_id == book_id:
                print(f"Book with ID {book_id} already exists.")
                unique = False
            if book.title == title:
                print(f"Book with title '{title}' already exists.")
                unique = False
        return unique
    def is_unique(self, book_id, title):
        all_books = self.books.get_all_books()
        for book in all_books:
            if book.book_id == book_id or book.title == title:
                return False
        return True

    def add(self):
        book_id = int(input("Enter book ID: "))
        title = input("Enter book title: ")
        author = input("Enter author: ")
        genre = input("Enter genre: ")
        publication = input("Enter publication year: ")
        availability = input("Enter availability (True/False): ").strip().lower() == 'true'
        borrow_count = int(input("Enter borrow count: "))
        aBook = Book(book_id, title, author, genre, publication, availability, borrow_count)
        if self.is_unique(book_id, title):
            self.books.insert(aBook)
            self.total += 1
            self.write_file(self.filename)  # Save file after adding
            print("Book added successfully.")



    def display(self):
        if self.total == 0:
            print("No books in inventory.")
        else:
            self.books.traverse(lambda book: book.print())

    def search(self, book_id):
        return self.books.search_tree(book_id)

    def search_by_attribute(self, attribute, value):
        results = []
        if attribute == "title":
            self.books.traverse(lambda book: results.append(book) if value.lower() in book.title.lower() else None)
        elif attribute == "author":
            self.books.traverse(lambda book: results.append(book) if value.lower() in book.author.lower() else None)
        elif attribute == "genre":
            self.books.traverse(lambda book: results.append(book) if value.lower() in book.genre.lower() else None)
        elif attribute == "publication":
            self.books.traverse(lambda book: results.append(book) if value.lower() in book.publication.lower() else None)
        else:
            print("Invalid attribute.")
            return

        if results:
            for book in results:
                book.print()
        else:
            print("No books found with the given attribute.")
        return results


    def search_book_by_title(self, title):
        result = []
        def check_title(book):
            if book.title == title:
                result.append(book)
        self.books.traverse(check_title)
        return result

    def search_book_by_author(self, author):
        result = []
        def check_author(book):
            if book.author == author:
                result.append(book)
        self.books.traverse(check_author)
        return result

    def search_book_by_genre(self, genre):
        result = []
        def check_genre(book):
            if book.genre == genre:
                result.append(book)
        self.books.traverse(check_genre)
        return result

    def search_book_by_publication_year(self, publication_year):
        result = []
        def check_publication_year(book):
            if book.publication == publication_year:
                result.append(book)
        self.books.traverse(check_publication_year)
        return result

    def search_book_by_id(self, book_id):
        return self.books.search_tree(book_id)

    def display_books_alphabetically(self):
        result = []
        self.books.traverse(result.append)
        return sorted(result, key=lambda book: book.title)
    def change(self):
        if self.logged_in_user is None:
            print("Please log in first.")
            return
        book_id = int(input("Enter book ID to modify: "))
        book = self.search(book_id)
        if book is None:
            print(f"Book with ID {book_id} does not exist.")
        else:
            print("Please enter the new information for this book (leave blank to keep current value):")
            title = input(f"Title ({book.title}): ") or book.title
            author = input(f"Author ({book.author}): ") or book.author
            genre = input(f"Genre ({book.genre}): ") or book.genre
            publication = input(f"Publication Year ({book.publication}): ") or book.publication
            availability = input(f"Availability ({'True' if book.availability else 'False'}): ").strip().lower() or str(book.availability)
            book.title = title
            book.author = author
            book.genre = genre
            book.publication = publication
            book.availability = availability == 'true'
            self.write_file(self.filename)  # Save file after modifying
            print("Book information has been successfully updated.")

    def display_sorted_by_title(self):
        sorted_books = []
        self.books.traverse(lambda book: sorted_books.append(book))
        for book in sorted(sorted_books, key=lambda x: x.title):
            book.print()

    def show_recent_borrowed_books(self):
        if self.logged_in_user is None:
            print("Please log in first.")
            return
        if not self.logged_in_user.borrow_history:
            print("You haven't borrowed any books yet.")
        else:
            print("Your recent borrowed books:")
            for book_title in self.logged_in_user.borrow_history[-5:]:
                print(book_title)

    def remove(self):
        if self.logged_in_user is None:
            print("Please log in first.")
            return
        book_id = int(input("Enter book ID to remove: "))
        book = self.search(book_id)
        if book is None:
            print(f"Book with ID {book_id} does not exist.")
        else:
            print("You will remove all the information of this book:")
            book.print()
            confirm = input("Are you sure you want to delete it? [y/n]: ")
            if confirm.lower() == 'y':
                self.books.remove(book)
                self.total -= 1
                self.write_file(self.filename)  # Save file after removing
                print(f"Book with ID {book_id} has been successfully removed from the inventory.")
    def recommend_books(self):
        try:
            # 找到借阅次数最多的书
            most_borrowed_book = None

            def update_most_borrowed(book):
                nonlocal most_borrowed_book
                if most_borrowed_book is None or book.borrow_count > most_borrowed_book.borrow_count:
                    most_borrowed_book = book

            self.books.traverse(update_most_borrowed)
            if most_borrowed_book is None:
                return "No books found."

            # 获取相同类别的书
            genre = most_borrowed_book.genre
            recommended_books = []

            def add_if_same_genre(book):
                if book.genre == genre and book != most_borrowed_book:
                    recommended_books.append(book)

            self.books.traverse(add_if_same_genre)

            if recommended_books:
                return recommended_books
            else:
                return "No other books found in the same genre."
        except Exception as e:
            import traceback
            traceback.print_exc()
            return f"An error occurred: {e}"

    def _update_most_borrowed(self, book, most_borrowed_book):
        if most_borrowed_book is None or book.borrow_count > most_borrowed_book.borrow_count:
            most_borrowed_book = book

    def _add_if_same_genre(self, book, genre, recommended_books):
        if book.genre == genre:
            recommended_books.append(book)
    def borrow_book(self, title):
        books = self.books.search_by_title(title)
        if books:
            for book in books:
                if book.availability:
                    book.availability = False
                    book.borrow_count += 1
                    self.write_file(self.filename)
                    return True, book
            return False, "Book is not available for borrowing."
        return False, "Book not found."
    def return_book(self, title):
        books = self.books.search_by_title(title)
        if books:
            for book in books:
                if not book.availability:
                    book.availability = True
                    self.write_file(self.filename)
                    return True, book
            return False, "The book is not currently borrowed."
        return False, "Book not found."
    def remove_book(self, book_id):
        book_to_remove = self.books.search_tree(book_id)
        if book_to_remove:
            self.books.remove(book_to_remove)
            return True
        return False