def recommend(self):
        print("Recommended books:")
        recommended_books = []
        self.books.traverse(lambda book: recommended_books.append(book))
        for book in sorted(recommended_books, key=lambda x: x.borrow_count, reverse=True)[:3]:
            book.print()
