
def lend(self):
        if self.logged_in_user is None:
            print("Please log in first.")
            return
        book_id = int(input("Enter book ID to lend: "))
        book = self.search(book_id)
        if book is None:
            print(f"Book with ID {book_id} does not exist.")
        elif not book.availability:
            print(f"Book '{book.title}' is currently not available.")
        else:
            book.availability = False
            book.borrow_count += 1
            self.logged_in_user.borrow_history.append(book.title)
            self.update_borrow_stats(self.logged_in_user)
            self.write_file(self.filename)  # Save file after lending
            self.write_user_file('users.csv')  # Save user file after lending
            print(f"Book '{book.title}' has been successfully lent.")

def update_borrow_stats(self, user):
        genre_count = {}
        author_count = {}
        for book_title in user.borrow_history:
            book = self.search_by_title(book_title)
            if book:
                genre_count[book.genre] = genre_count.get(book.genre, 0) + 1
                author_count[book.author] = author_count.get(book.author, 0) + 1

        user.most_borrowed_genre = max(genre_count, key=genre_count.get) if genre_count else ""
        user.most_borrowed_author = max(author_count, key=author_count.get) if author_count else ""


def return_book(self):
        if self.logged_in_user is None:
            print("Please log in first.")
            return
        book_id = int(input("Enter book ID to return: "))
        book = self.search(book_id)
        if book is None:
            print(f"Book with ID {book_id} does not exist.")
        elif book.availability:
            print(f"Book '{book.title}' is not currently lent out.")
        else:
            book.availability = True
            self.write_file(self.filename)  # Save file after returning
            print(f"Book '{book.title}' has been successfully returned.")

