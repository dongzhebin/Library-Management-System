def read_csv_file(filename):
    with open(filename, 'r', newline='', encoding='utf-8') as inFile:
        reader = csv.reader(inFile)
        data = list(reader)
    return data
