import csv
import unittest

class Book:
    def __init__(self, book_id=0, title="", author="", genre="", publication="", availability=True, borrow_count=0):    
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.publication = publication
        self.availability = availability
        self.borrow_count = borrow_count

    def print(self):
        print("-------------------------------")
        print("Book information:")
        print(f"ID: {self.book_id}")
        print(f"Title: {self.title}")
        print(f"Author: {self.author}")
        print(f"Genre: {self.genre}")
        print(f"Publication Year: {self.publication}")
        print(f"Availability: {'Available' if self.availability else 'Not Available'}")
        print(f"Borrow Count: {self.borrow_count}")
        print("-------------------------------")

    def __eq__(self, other):
        return self.book_id == other.book_id

    def __lt__(self, other):
        return self.book_id < other.book_id

    def __gt__(self, other):
        return self.book_id > other.book_id
