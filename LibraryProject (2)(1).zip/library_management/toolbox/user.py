
class User:
    def __init__(self, nickname, username, password):
        self.nickname = nickname
        self.username = username
        self.password = password
        self.borrow_history = []
        self.most_borrowed_genre = ""
        self.most_borrowed_author = ""