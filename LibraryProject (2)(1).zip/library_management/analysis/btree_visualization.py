import csv
import matplotlib.pyplot as plt
import networkx as nx

class BTreeNode:
    def __init__(self, t, leaf=False):
        self.t = t  # Minimum degree (defines the range for number of keys)
        self.leaf = leaf  # True if leaf node, else False
        self.keys = []  # List of keys
        self.children = []  # List of child pointers

class BTree:
    def __init__(self, t):
        self.root = BTreeNode(t, True)
        self.t = t

    def insert(self, k):
        root = self.root
        if len(root.keys) == (2 * self.t) - 1:
            temp = BTreeNode(self.t)
            self.root = temp
            temp.children.insert(0, root)
            self._split_child(temp, 0)
            self._insert_non_full(temp, k)
        else:
            self._insert_non_full(root, k)

    def _insert_non_full(self, x, k):
        i = len(x.keys) - 1
        if x.leaf:
            x.keys.append(0)
            while i >= 0 and k < x.keys[i]:
                x.keys[i + 1] = x.keys[i]
                i -= 1
            x.keys[i + 1] = k
        else:
            while i >= 0 and k < x.keys[i]:
                i -= 1
            i += 1
            if len(x.children[i].keys) == (2 * self.t) - 1:
                self._split_child(x, i)
                if k > x.keys[i]:
                    i += 1
            self._insert_non_full(x.children[i], k)

    def _split_child(self, x, i):
        t = self.t
        y = x.children[i]
        z = BTreeNode(t, y.leaf)
        x.children.insert(i + 1, z)
        x.keys.insert(i, y.keys[t - 1])
        z.keys = y.keys[t:(2 * t) - 1]
        y.keys = y.keys[0:t - 1]
        if not y.leaf:
            z.children = y.children[t:2 * t]
            y.children = y.children[0:t]

def read_book_ids(file_path):
    book_ids = []
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        headers = reader.fieldnames
        print("CSV Headers:", headers)
        for row in reader:
            book_ids.append(int(row['ID']))
    return book_ids

def draw_btree(node, pos=None, x=0, y=0, layer=1, dx=1.0):
    if pos is None:
        pos = {}
    pos[(x, y)] = node.keys

    if not node.leaf:
        next_y = y - 1
        for i, child in enumerate(node.children):
            next_x = x + (i - len(node.children) / 2) * dx / layer
            draw_btree(child, pos, next_x, next_y, layer + 1, dx)

    return pos

def plot_btree(btree):
    pos = draw_btree(btree.root)
    G = nx.DiGraph()

    for (x, y), keys in pos.items():
        G.add_node((x, y), label='|'.join(map(str, keys)))
        for (child_x, child_y) in [(cx, cy) for (cx, cy) in pos if cy == y - 1]:
            if abs(child_x - x) < 1 / (2 ** (y - 1)):
                G.add_edge((x, y), (child_x, child_y))

    plt.figure(figsize=(12, 8))
    pos = {k: (k[0], -k[1]) for k in G.nodes()}
    labels = nx.get_node_attributes(G, 'label')
    nx.draw(G, pos, with_labels=True, labels=labels, node_size=2000, node_color='skyblue', font_size=10, font_color='black', font_weight='bold', arrows=False)
    plt.show()

# 读取 CSV 文件并获取书籍 ID
file_path = 'files/library_books_dataset.csv'
book_ids = read_book_ids(file_path)

# 添加更多书籍 ID 以增加树的层级
additional_book_ids = []
book_ids.extend(additional_book_ids)

# 创建 B-Tree 并插入书籍 ID
t = 2  # B-Tree of order 2
btree = BTree(t)
for book_id in book_ids:
    btree.insert(book_id)

# 绘制 B-Tree
plot_btree(btree)