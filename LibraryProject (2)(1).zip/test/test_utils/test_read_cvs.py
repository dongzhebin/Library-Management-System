import unittest
from unittest.mock import mock_open, patch, MagicMock
from library_management.toolbox.library import Library
from library_management.toolbox.book import Book
from library_management.toolbox.user import User
from library_management.toolbox.btree import BTree


# test_read_csv.py
import unittest
from library_management.utils.read_csv import read_csv_file
# test_read_csv.py
import unittest
import csv  # Import the csv module
import os

class TestReadCSVFile(unittest.TestCase):
    
    def setUp(self):
        # Create a temporary CSV file for testing
        self.filename = 'test_file.csv'
        with open(self.filename, 'w', newline='', encoding='utf-8') as outFile:
            writer = csv.writer(outFile)
            writer.writerow(['Header1', 'Header2', 'Header3'])
            writer.writerow(['Row1Col1', 'Row1Col2', 'Row1Col3'])
            writer.writerow(['Row2Col1', 'Row2Col2', 'Row2Col3'])

    def tearDown(self):
        # Remove the temporary CSV file after testing
        os.remove(self.filename)

    def test_read_csv_file(self):
        expected_data = [
            ['Header1', 'Header2', 'Header3'],
            ['Row1Col1', 'Row1Col2', 'Row1Col3'],
            ['Row2Col1', 'Row2Col2', 'Row2Col3']
        ]
        result = read_csv_file(self.filename)
        self.assertEqual(result, expected_data)

if __name__ == '__main__':
    unittest.main()
