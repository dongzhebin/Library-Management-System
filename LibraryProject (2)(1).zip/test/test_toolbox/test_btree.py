import unittest
from library_management.toolbox.book import Book  # Ensure correct import path
from library_management.toolbox.btree import BTree  # Ensure correct import path

class TestBTree(unittest.TestCase):

    def setUp(self):
        self.btree = BTree(2)  # Initialize BTree with minimum degree 2

    def test_insert_and_search(self):
        book1 = Book(1, "Test Book 1", "Author 1", "Genre 1", "2023")
        book2 = Book(2, "Test Book 2", "Author 2", "Genre 2", "2024")

        self.btree.insert(book1)
        self.btree.insert(book2)

        self.assertEqual(self.btree.search_tree(1), book1)
        self.assertEqual(self.btree.search_tree(2), book2)

    def test_traverse(self):
        book1 = Book(1, "Test Book 1", "Author 1", "Genre 1", "2023")
        book2 = Book(2, "Test Book 2", "Author 2", "Genre 2", "2024")

        self.btree.insert(book1)
        self.btree.insert(book2)

        results = []
        self.btree.traverse(lambda x: results.append(x.book_id))

        self.assertEqual(results, [1, 2])

    def test_remove(self):
        book1 = Book(1, "Test Book 1", "Author 1", "Genre 1", "2023")
        book2 = Book(2, "Test Book 2", "Author 2", "Genre 2", "2024")

        self.btree.insert(book1)
        self.btree.insert(book2)

        self.btree.remove(1)
        self.assertIsNone(self.btree.search_tree(1))

        self.btree.remove(2)
        self.assertIsNone(self.btree.search_tree(2))

if __name__ == "__main__":
    unittest.main()
