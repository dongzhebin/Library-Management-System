import unittest
from unittest.mock import patch
from library_management.toolbox.library import Library
from library_management.toolbox.book import Book
from library_management.analysis.recommandation import recommend
from io import StringIO


class TestLibraryRecommendation(unittest.TestCase):
    def setUp(self):
        # Set up a mock library with predefined books
        self.library = Library('test/test_analysis/test_books.csv')  # Replace 'test_books.csv' with your test file path
        self.book1 = Book(1, "Book A", "Author A", "Genre A", "2020", True, 5)
        self.book2 = Book(2, "Book B", "Author B", "Genre B", "2021", True, 8)
        self.book3 = Book(3, "Book C", "Author C", "Genre A", "2019", True, 3)
        self.book4 = Book(4, "Book D", "Author D", "Genre C", "2022", True, 7)
        self.library.books.insert(self.book1)
        self.library.books.insert(self.book2)
        self.library.books.insert(self.book3)
        self.library.books.insert(self.book4)

    @patch('sys.stdout', new_callable=StringIO)
    def test_recommend_function(self, mock_stdout):
        # Call recommend function
        recommend(self.library)

        # Capture printed output
        printed_output = mock_stdout.getvalue()

        # Split the output into lines and extract book IDs
        recommended_books = []
        for line in printed_output.splitlines():
            if line.startswith("ID:"):
                book_id = int(line.split(":")[1].strip())
                recommended_books.append(book_id)

        # Check if recommended_books contains the top 3 most borrowed books
        self.assertEqual(len(recommended_books), 3)
        self.assertIn(self.book2.book_id, recommended_books)
        self.assertIn(self.book4.book_id, recommended_books)
        self.assertIn(self.book1.book_id, recommended_books)


if __name__ == '__main__':
    unittest.main()
