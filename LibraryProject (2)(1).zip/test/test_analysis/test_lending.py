import unittest
from unittest.mock import patch
from io import StringIO
from library_management.toolbox.library import Library
from library_management.toolbox.user import User
from library_management.toolbox.book import Book
from library_management.analysis.lending import lend, return_book
from library_management.analysis.lending import update_borrow_stats

import unittest
from unittest.mock import patch, MagicMock

import unittest
from unittest.mock import patch, MagicMock, mock_open




class TestLibraryLending(unittest.TestCase):
    def setUp(self):
        # 使用 mock_open 模拟打开文件
        self.mock_open = mock_open(read_data="book_id,title,author,genre,availability,borrow_count\n"
                                             "1,Test Book,Test Author,Test Genre,True,0")
        
        # 设置一个 library 实例和一个用户
        with patch('builtins.open', self.mock_open):
            self.library = Library(filename='test_books.csv')
        
        # 初始化用户实例
        self.user = User(username="test_user", nickname="test_nickname", password="test_password")
        self.library.logged_in_user = self.user
        self.library.write_file = MagicMock()
        self.library.write_user_file = MagicMock()

    
    @patch('builtins.input', side_effect=['2'])
    def test_lend_book(self, mock_input):
        self.library.search = MagicMock(return_value=None)
        
        lend(self.library)
        
        self.library.write_file.assert_not_called()
        self.library.write_user_file.assert_not_called()

    @patch('builtins.input', side_effect=['1'])
    def test_lend_book_not_available(self, mock_input):
        book = Book(book_id=1, title="Test Book", author="Test Author", genre="Test Genre", availability=False, borrow_count=0)
        self.library.search = MagicMock(return_value=book)
        
        lend(self.library)
        
        self.library.write_file.assert_not_called()
        self.library.write_user_file.assert_not_called()

    @patch('builtins.input', side_effect=['1'])
    def test_return_book(self, mock_input):
        book = Book(book_id=1, title="Test Book", author="Test Author", genre="Test Genre", availability=False, borrow_count=1)
        self.library.search = MagicMock(return_value=book)
        
        return_book(self.library)
        
        self.assertTrue(book.availability)
        self.library.write_file.assert_called_with('test_books.csv')

    @patch('builtins.input', side_effect=['2'])
    def test_return_book_not_exist(self, mock_input):
        self.library.search = MagicMock(return_value=None)
        
        return_book(self.library)
        
        self.library.write_file.assert_not_called()

    @patch('builtins.input', side_effect=['1'])
    def test_return_book_already_available(self, mock_input):
        book = Book(book_id=1, title="Test Book", author="Test Author", genre="Test Genre", availability=True, borrow_count=1)
        self.library.search = MagicMock(return_value=book)
        
        return_book(self.library)
        
        self.library.write_file.assert_not_called()

if __name__ == '__main__':
    unittest.main()
